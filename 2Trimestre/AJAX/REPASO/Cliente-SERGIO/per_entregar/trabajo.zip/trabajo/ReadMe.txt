
www.free-responsive-templates.com - the biggest collection of Free Responsive Templates on the net!

www.free-responsive-templates.com/blog - a lot information about Responsive Web Design!